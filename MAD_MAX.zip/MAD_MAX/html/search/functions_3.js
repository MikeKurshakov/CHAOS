var searchData=
[
  ['gotoxy',['gotoxy',['../validation_8c.html#a163cc3dfe07ad8da53c2a165f796992f',1,'validation.c']]]
];
