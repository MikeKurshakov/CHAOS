var searchData=
[
  ['student',['Student',['../struct_student.html',1,'Student'],['../validation_8c.html#a39faca217ca091b5f20c551a97def951',1,'student():&#160;validation.c']]],
  ['surname',['surname',['../struct_examiner.html#ac8b846ed00e1eb3101fd72e743db47f7',1,'Examiner::surname()'],['../struct_student.html#ad08d3c3ae9b9c2a8989d2d3a70a255e5',1,'Student::surname()']]]
];
