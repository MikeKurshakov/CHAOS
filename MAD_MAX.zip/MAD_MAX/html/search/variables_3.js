var searchData=
[
  ['mark',['mark',['../struct_student.html#a34a87d488278064d1efe254e5d1b9d9c',1,'Student']]],
  ['mark_5fquantity',['mark_quantity',['../struct_student.html#a4c85a0d8727b8321474b379a88898c95',1,'Student']]]
];
