var searchData=
[
  ['textcolor',['textcolor',['../validation_8c.html#a0665d20f9aa4cf361be6f24ac8d63c96',1,'validation.c']]]
];
