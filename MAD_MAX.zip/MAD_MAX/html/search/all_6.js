var searchData=
[
  ['list_5fexaminer',['list_examiner',['../validation_8c.html#a456480ac735950cc57e5c774c38db98b',1,'validation.c']]],
  ['list_5fstudent',['list_student',['../validation_8c.html#a28e2f50a000c1c0764e8d659c9b72fbd',1,'validation.c']]]
];
