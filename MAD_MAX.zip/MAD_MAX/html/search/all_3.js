var searchData=
[
  ['father_5fname',['father_name',['../struct_examiner.html#adbf6926c7b1109e8f9cd686738fbdb60',1,'Examiner::father_name()'],['../struct_student.html#a221fed3ff11c37843f5377d1bdc850ec',1,'Student::father_name()']]],
  ['free_5fmemory',['free_memory',['../validation_8c.html#a9f81a9a3690fcba7180fa860e0c2422f',1,'validation.c']]]
];
