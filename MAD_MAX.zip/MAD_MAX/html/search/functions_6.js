var searchData=
[
  ['new_5fexaminer',['new_examiner',['../validation_8c.html#a19ed0123210df8aeaface3c26eabecf6',1,'validation.c']]],
  ['new_5fstudent',['new_student',['../validation_8c.html#a4ca03053420bf795e17e98c87b237079',1,'validation.c']]]
];
