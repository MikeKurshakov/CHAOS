var searchData=
[
  ['surname',['surname',['../struct_examiner.html#ac8b846ed00e1eb3101fd72e743db47f7',1,'Examiner::surname()'],['../struct_student.html#ad08d3c3ae9b9c2a8989d2d3a70a255e5',1,'Student::surname()']]]
];
