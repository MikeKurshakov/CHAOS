var searchData=
[
  ['gotoxy',['gotoxy',['../validation_8c.html#a163cc3dfe07ad8da53c2a165f796992f',1,'validation.c']]],
  ['group',['group',['../struct_student.html#a43370e2035516fe410d63f5b7665da95',1,'Student']]]
];
