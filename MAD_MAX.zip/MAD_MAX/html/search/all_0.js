var searchData=
[
  ['add_5fnew_5fexaminer',['add_new_examiner',['../validation_8c.html#a8b0bb6454be31a17bc405ea9722f9ec8',1,'validation.c']]],
  ['add_5fnew_5fstudent',['add_new_student',['../validation_8c.html#a27721936a47cba0d83e1f5c3e7353b29',1,'validation.c']]]
];
