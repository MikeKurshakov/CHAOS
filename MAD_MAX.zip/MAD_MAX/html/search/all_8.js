var searchData=
[
  ['name',['name',['../struct_examiner.html#a30639eb9d192d0683b01860afaac427c',1,'Examiner::name()'],['../struct_student.html#a77d2f15ecf824116a4757889763aa956',1,'Student::name()']]],
  ['new_5fexaminer',['new_examiner',['../validation_8c.html#a19ed0123210df8aeaface3c26eabecf6',1,'validation.c']]],
  ['new_5fstudent',['new_student',['../validation_8c.html#a4ca03053420bf795e17e98c87b237079',1,'validation.c']]],
  ['next_5f1',['next_1',['../struct_examiner.html#af8a282ff70e89df7d0bf5b7e119407d4',1,'Examiner']]],
  ['next_5f2',['next_2',['../struct_student.html#a15956818b2ed294dbb00ba367e125a94',1,'Student']]]
];
