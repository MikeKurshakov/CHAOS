var searchData=
[
  ['student',['student',['../validation_8c.html#a39faca217ca091b5f20c551a97def951',1,'validation.c']]]
];
